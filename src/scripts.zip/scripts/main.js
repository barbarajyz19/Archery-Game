
// importation de la classe Game.js
import Game from './game.js';
import Arc from './arc.js';


// mise en place de l'action des clics sur les boutons + les gestionnaires du clavier pour contrôler le panier
const init = () => {
   const canvas = document.getElementById("playfield");
   const arc = new Arc(210, 500);
   const game = new Game(canvas,arc);

   document.getElementById("stopAndStartGame").addEventListener("click", () => game.startAndStop());
}

window.addEventListener("load", init);

//
console.log('le bundle a été généré');
