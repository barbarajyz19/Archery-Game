export default class Game {

   #canvas;
   #arc;
   #context;
   #animation;
   // à compléter

   constructor(canvas, arc) {
      this.#canvas = canvas;
      this.#arc = arc;
      this.#context = canvas.getContext('2d');
      this.#animation = null;
      // à compléter
   }

   animate() {
      this.#context.clearRect(0, 0, this.#canvas.width, this.#canvas.height);
      this.#arc.draw(this.#context);
      this.#animation = window.requestAnimationFrame(this.animate.bind(this));
  }

   startAndStop() {
      if (this.animation) {
        cancelAnimationFrame(this.animation);
        this.animation = null;
      } else {
        this.animate();
      }
    }

   // Getters
   /** donne accès au canvas correspondant à la zone de jeu */
   get canvas() {
      return this.#canvas;
   }

   get arc() {
      return this.#arc;
   }

   
}



