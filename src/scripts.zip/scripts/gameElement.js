
export default class GameElement {

    #x;
    #y;
    #deltaX;
    #deltaY;
    #image;

  constructor(x, y, deltaX = 0, deltaY = 0, cheminImg) {
    this.#x = x;
    this.#y = y;
    this.#deltaX = deltaX;
    this.#deltaY = deltaY;
    this.#image = this.#createImage(cheminImg);
  }

  /* draw this ball, using the given drawing 2d context */
  draw(context) {
    context.drawImage(this.Image, this.X, this.Y);
  }

  move(canvas) {
    let newX = this.X + this.DeltaX;
    let newY = this.Y + this.DeltaY;
    if ((newX < 0) || (newX > canvas.width - this.Image.width)) {
      this.DeltaX = -this.DeltaX;
    }
    if ((newY < 0) || (newY > canvas.height - this.Image.height)) {
      this.DeltaY = -this.DeltaY;
    }
    this.X += this.DeltaX;
    this.Y += this.DeltaY;
  }

  #createImage(imageSource) {
    const newImg = new Image();
    newImg.src = imageSource;
    return newImg;
    }
  // Getters
  get X() {
    return this.#x;
  }

  get Y() {
    return this.#y;
  }

  get DeltaX() {
    return this.#deltaX;
  }

  get DeltaY() {
    return this.#deltaY;
  }

  get Image() {
    return this.#image;
  }


  // Setters
  set X(value) {
    this.#x = value;
  }

  set Y(value) {
    this.#y = value;
  }

  set DeltaX(value) {
    this.#deltaX = value;
  }

  set DeltaY(value) {
    this.#deltaY = value;
  }

  set Image(value) {
    this.#image = value;
  }

}