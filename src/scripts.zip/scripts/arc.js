import GameElement from "./gameElement";
import arc from './assets/images/arc.png';

export default class Arc extends GameElement {

    static ARR_MAX = 5;

    #nbArrows;

    constructor(x, y, deltaX = 0, deltaY = 0){
        super(x, y, deltaX, deltaY, arc);
        this.NbArrows = Arc.ARR_MAX;
    }

    get NbArrows(){
        return this.#nbArrows;
    }

    set NbArrows(value){
        this.#nbArrows = value;
    }
}